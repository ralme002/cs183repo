#!/usr/bin/env python
##i just want to say that regex is difficult to master :( why would you put us through this pain
import sys
import re

input=str(sys.argv[1])

with open(input) as hp:
 line = hp.read()
 hp = re.findall(r'(?<=from=)(.*?)(?=>)',line)
 myList=list()
 for n in hp:
  myList.append(n[1:])

 uniqueList=list(dict.fromkeys(myList))
 
 #print(len(myList))
 #print(len(uniqueList))
 countList=list()

 #nest that mofo go through each unique and count how many repeats we got, index not changing
 count=0 #keep count of how often it appears
 for x in uniqueList:
  count=1 #at least appears one time  ALSO a reset
  for y in myList:
   if x == y:
    count+=1
  countList.append(count) #after nested y loop finishes we store the counter
 #at this point after loop countList holds number of times a unique was found

 unoplace=list()
  
 for o in range(0,5):
  unoplace.append(max(countList))
  indexcurrent =countList.index(max(countList))
  unoplace.append(uniqueList[indexcurrent])
  del uniqueList[indexcurrent]
  del countList[indexcurrent]
 
 u=0
 for p in range(0,5):   
  print("From "+ str(unoplace[u+1]) +"  " +  str(unoplace[u])) 
  u+=2

 ## COPY AND PASTE kinda  -- redo with to= instead of from=
with open(input) as hp:
 line = hp.read()
 hp = re.findall(r'(?<=to=)(.*?)(?=>)',line)
 myList=list()
 for n in hp:
  myList.append(n[1:])

 uniqueList=list(dict.fromkeys(myList))
 
 #print(len(myList))
 #print(len(uniqueList))
 countList=list()

 #nest that mofo go through each unique and count how many repeats we got, index not changing
 count=0 #keep count of how often it appears
 for x in uniqueList:
  count=1 #at least appears one time  ALSO a reset
  for y in myList:
   if x == y:
    count+=1
  countList.append(count) #after nested y loop finishes we store the counter
 #at this point after loop countList holds number of times a unique was found

 unoplace=list()
  
 for o in range(0,5):
  unoplace.append(max(countList))
  indexcurrent =countList.index(max(countList))
  unoplace.append(uniqueList[indexcurrent])
  del uniqueList[indexcurrent]
  del countList[indexcurrent]
 
 u=0
 for p in range(0,5):   
  print("To "+ str(unoplace[u+1]) +"  " +  str(unoplace[u])) 
  u+=2 
