#!/bin/bash

file="/root/monitortest.txt"
output="/var/log/cs183/uptime.log"
time=$( date +"%m-%d-%y  %T ")

if [ -f "$file" ]; then
	echo "$time -File \"$file\" has been found" >> "$output"
else
	echo "$time -File \"$file\" has been lost" >> "$output"
fi
