#!/bin/bash
# this script prints out the number lines of code with the word "magic" on them in the Linux kernel
# source tree. This only counts intances in files ending with a .h extension

#in order to accomplish this task it will be required to install the kernel-devel package first and #figure out where it is placing files and use 'find' command to find the filenames that end in .h


find /usr/src/kernels -name \*.h -type f -exec grep -i "magic" /dev/null '{}' \+ > count_lines.txt
wc -l < count_lines.txt
echo "done found with the word magic in it, with any mixtures of upper and lower case chars" >>total.txt
rm -f count_lines.txt
rm -f total.txt
