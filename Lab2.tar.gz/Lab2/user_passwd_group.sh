#!/bin/sh
#this script enumarates system user and groups from /etc/password and /etc/group

###  use awk command to pull the needed information from the passwd file
myarr11=($(awk -F: '{print $1}' /etc/passwd))
myarr13=($(awk -F: '{print $3}' /etc/passwd))
myarr14=($(awk -F: '{print $4}' /etc/passwd))
### use awk command to pull the needed information from the group file
myarr21=($(awk -F: '{print $3}' /etc/group))
myarr22=($(awk -F: '{print $1}' /etc/group))

### use nested for loop iterating through array14 and array21 comparing elements
### when pair is found then input the at element counter is copied from array 22 into 14

count=0
for i in ${myarr14[@]}; do
	counter=0	
	for j in ${myarr21[@]}; do
	 if [ $i -eq $j ]
	  then
	  myarr14[$count]=${myarr22[$counter]}
	 fi
	counter=$((counter+1))
	done
count=$((count+1))
done

### output for array11, array13, array14 in proper output to view

count=0
for i in ${myarr11[@]}; do
	echo "${myarr11[$count]}" "${myarr13[$count]}" "${myarr14[$count]}"
	count=$((count+1))
done
