#!/bin/bash

echo "  NOW searching in /bin"
find /bin -type f -user root -perm -4000 > bin.txt
cat bin.txt
rm -f bin.txt

echo "  NOW searching in /sbin"
find /sbin -type f -user root -perm -4000 > sbin.txt
cat sbin.txt
rm -f sbin.txt

echo "  NOW searching in /usr/bin"
find /usr/bin -type f -user root -perm -4000 > first.txt
cat first.txt

echo "  NOW searching in /usr/sbin"
find /usr/sbin -type f -user root -perm -4000  > sec.txt
cat sec.txt

read -p "hit Enter to continue"
#clear
echo " NOW part 2"

find / -perm /6000 > bin.txt
cat bin.txt
rm -f bin.txt
read -p "hit Enter to continue"

echo " NOW part 3"

find /var -type f -mmin -20
read -p "hit Enter to continue"

echo " NOW part 4"

find /var -type f -size 0
read -p "hit Enter to continue"

echo " NOW part 5"

find /dev -type b -exec ls -s -ldb {} \;
find /dev -type c -exec ls -s -ldb {} \;
find /dev -type p -exec ls -s -ldb {} \;
find /dev -type l -exec ls -s -ldb {} \;
find /dev -type s -exec ls -s -ldb {} \;

read -p "hit Enter to continue"

echo "  NOW PART 6"
#find /home -type d \! -user root -exec chmod 711 {} \;
find /home -type d \! -user root -exec chmod 711 {} \; 

read -p "hit Enter to continue"

echo "  NOW PART 7"
find /home -type f \! -user root -exec chmod 755 {} \; 
read -p "hit Enter to continue"

echo "  NOW PART 8"
find /etc -mtime -5





